package com.xd.sy.sysj.mi;

import android.os.Bundle;
import android.widget.Toast;

import com.xiaomi.gamecenter.sdk.GameInfoField;
import com.xiaomi.gamecenter.sdk.MiCommplatform;
import com.xiaomi.gamecenter.sdk.MiErrorCode;
import com.xiaomi.gamecenter.sdk.OnExitListner;
import com.xiaomi.gamecenter.sdk.OnLoginProcessListener;
import com.xiaomi.gamecenter.sdk.OnPayProcessListener;
import com.xiaomi.gamecenter.sdk.entry.MiAccountInfo;
import com.xiaomi.gamecenter.sdk.entry.MiBuyInfo;
import com.hw.mag.Lanucher;

import org.json.JSONObject;

public class MainActivity extends Lanucher implements ISDKBase
{
    Bundle playerInfo = new Bundle();
    public static final int channelID = 7;
    
	@Override protected void onCreate (Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
        super.startup();
	}

	@Override
	public void SDKServiceInit() {
        UnityCallback.Invoke(UnityCallback.FuncName.Init, ","+channelID);
	}


	@Override
	public void SDKServiceLogin() {
		MiCommplatform.getInstance().miLogin(this, new OnLoginProcessListener(){
			@Override
			public void finishLoginProcess( int code,MiAccountInfo arg1) {
            switch( code ) {
                case MiErrorCode.MI_XIAOMI_GAMECENTER_SUCCESS:
                    // 登陆成功
                    //获取用户的登陆后的 UID(即用户唯一标识)
                    long uid = arg1.getUid();
                    //获取用户的登陆的 Session(请参考 3.3用户session验证接口)
                    String session = arg1.getSessionId();//若没有登录返回 null
                    //请开发者完成将uid和session提交给开发者自己服务器进行session验证

                    try
                    {
                        JSONObject json = new JSONObject();
							json.put("userid", Long.toString(uid));
                        json.put("uid", Long.toString(uid));
                        json.put("session", session);

                        UnityCallback.Invoke(UnityCallback.FuncName.Login, json.toString());
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }

                    break;
                case MiErrorCode.MI_XIAOMI_GAMECENTER_ERROR_LOGIN_FAIL:
                    // 登陆失败
                    UnityCallback.Invoke(UnityCallback.FuncName.Login, "login fail");
                    break;
                case MiErrorCode.MI_XIAOMI_GAMECENTER_ERROR_CANCEL:
                    // 取消登录
                    UnityCallback.Invoke(UnityCallback.FuncName.Login, "login fail");
                    break;
                case MiErrorCode.MI_XIAOMI_GAMECENTER_ERROR_ACTION_EXECUTED:
                    // 登录操作正在进行中
                    UnityCallback.Invoke(UnityCallback.FuncName.Login, "login fail");
                    break;
                default :
                    // 登录失败
                    UnityCallback.Invoke(UnityCallback.FuncName.Login, "login fail");
                    break;
            }
			}
		});
	}

	@Override
	public void SDKServiceLogout() {
        UnityCallback.Invoke(UnityCallback.FuncName.Logout, "");
	}

	@Override
	public void SDKServiceShowCenter(int pos) {

	}

	@Override
	public void SDKServicePurchase(final String productId,final String productName,final String amount,final String count,final String orderIdCom,final String exParam) {
        MiBuyInfo info = new MiBuyInfo();
        info.setCpOrderId(orderIdCom);
        info.setAmount(Float.valueOf(amount).intValue());
        info.setExtraInfo(playerInfo);
        MiCommplatform.getInstance().miUniPay(this, info, new OnPayProcessListener() {
            @Override
            public void finishPayProcess(int i) {
                switch( i ) {
                    case MiErrorCode.MI_XIAOMI_PAYMENT_SUCCESS:
                        //购买成功，请处理发货
                        //UnityCallback.Invoke(UnityCallback.FuncName.Pay, "");
                        //showInfo("支付成功");
                        UnityCallback.OnPaySuccess(productId, orderIdCom, exParam, "", productId);
                        break;
                    case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_CANCEL:
                        //取消购买
                        //showInfo("用户取消");
                        UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(i), "");
                        break;
                    case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_PAY_FAILURE:
                        //购买失败
                        //showInfo("购买失败");
                        UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(i), "");
                        break;
                    case MiErrorCode.MI_XIAOMI_PAYMENT_ERROR_ACTION_EXECUTED:
                        //操作正在执行
                        //showInfo("操作正在执行");
                        UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(i), "");
                        break;
                    default:
                        //购买失败
                        UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(i), "");
                        break;
                }
            }
        });
	}

	@Override
	public void SDKServiceExitSDK() {
	    MiCommplatform.getInstance().miAppExit(this, new OnExitListner() {
            @Override
            public void onExit(int i) {
                if(i == MiErrorCode.MI_XIAOMI_EXIT)
                {
                    UnityCallback.Invoke(UnityCallback.FuncName.Exit, "");
                }
            }
        });

	}

	@Override
	public void SDKServiceSubmitExtendData(String jsonStr) {
	    try {
            JSONObject jsonObject = new JSONObject(jsonStr);
//            playerInfo.putString(GameInfoField.GAME_USER_BALANCE, "");
//            playerInfo.putString(GameInfoField.GAME_USER_GAMER_VIP, "");
            playerInfo.putString(GameInfoField.GAME_USER_LV, jsonObject.getString("roleLevel"));
            playerInfo.putString(GameInfoField.GAME_USER_ROLE_NAME, jsonObject.getString("roleName"));
            playerInfo.putString(GameInfoField.GAME_USER_ROLEID, jsonObject.getString("roleId"));
//            playerInfo.putString(GameInfoField.GAME_USER_PARTY_NAME, "");
            playerInfo.putString(GameInfoField.GAME_USER_SERVER_NAME, jsonObject.getString("serverName"));
        }catch (Exception e){
	        e.printStackTrace();
        }
	}

	@Override
	public String getChannelName() {
		return null;
	}

	@Override
	public String getChannelVersion() {
		return null;
	}

	@Override
	public int getChannelType() {
		return 0;
	}

	@Override
	public String getSDKVersion() {
		return null;
	}

	@Override
	public boolean isChannelHasExitDialog() {
		return true;
	}

    private void showInfo(String msg)
    {
        Toast.makeText(this.getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }
}
