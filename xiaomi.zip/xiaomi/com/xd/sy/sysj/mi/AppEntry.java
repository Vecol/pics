package com.xd.sy.sysj.mi;

import android.app.Application;

import com.xiaomi.gamecenter.sdk.MiCommplatform;
import com.xiaomi.gamecenter.sdk.entry.MiAppInfo;
import com.xiaomi.gamecenter.sdk.entry.MiAppType;

/**
 * Created by Administrator on 2018/1/5.
 */

public class AppEntry extends Application {
    public static final String appID = "2882303761517678109";
    public static final String appKey = "5741767838109";
    public static final int channelID = 7;

    @Override
    public void onCreate() {
        super.onCreate();
        MiAppInfo info = new MiAppInfo();
        info.setAppId(appID);
        info.setAppKey(appKey);
        info.setAppType(MiAppType.online);
        MiCommplatform.Init(this, info);

        UnityCallback.Invoke(UnityCallback.FuncName.Init, ","+channelID);
    }
}
