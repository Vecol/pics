package com.xd.sy.sysj.mz;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.meizu.gamesdk.model.callback.MzExitListener;
import com.meizu.gamesdk.model.callback.MzLoginListener;
import com.meizu.gamesdk.model.callback.MzPayListener;
import com.meizu.gamesdk.model.model.LoginResultCode;
import com.meizu.gamesdk.model.model.MzAccountInfo;
import com.meizu.gamesdk.model.model.PayResultCode;
import com.meizu.gamesdk.online.core.MzGameBarPlatform;
import com.meizu.gamesdk.online.core.MzGameCenterPlatform;
import com.meizu.gamesdk.online.model.model.MzBuyInfo;

import org.json.JSONObject;
import com.hw.mag.Lanucher;


public class MainActivity extends Lanucher implements  ISDKBase
{
    public static final String TAG = "sysj.mz";
    public static final int channelID = 8;

	MzGameBarPlatform gamebar;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		super.startup();

		gamebar = new MzGameBarPlatform(this);
		gamebar.onActivityCreate();
	}

    @Override
    protected void onPause() {
        super.onPause();
        gamebar.onActivityPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        gamebar.onActivityResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        gamebar.onActivityDestroy();
    }

    @Override
	public void SDKServiceInit() {
        UnityCallback.Invoke(UnityCallback.FuncName.Init, ","+channelID);
	}

	@Override
	public void SDKServiceLogin() {
	    runOnUiThread(new Runnable() {
            @Override
            public void run() {
			MzGameCenterPlatform.login(MainActivity.this, new MzLoginListener() {
				@Override
				public void onLoginResult(int i, MzAccountInfo mzAccountInfo, String s) {
				if( i == LoginResultCode.LOGIN_SUCCESS)
				{
					gamebar.showGameBar();
                    Log.i(TAG, "onLoginResult: called");

					String uid = mzAccountInfo.getUid();
					String session = mzAccountInfo.getSession();

					try {
						JSONObject json = new JSONObject();
						json.put("userid", uid);
						json.put("uid", uid);
						json.put("session", session);

						UnityCallback.Invoke(UnityCallback.FuncName.Login, json.toString());

					}catch (Exception e)
					{
						e.printStackTrace();
					}
					return;
				}

				UnityCallback.Invoke(UnityCallback.FuncName.Login, "fail");
				}
			});
            }
        });
	}

	@Override
	public void SDKServiceLogout() {
	    runOnUiThread(new Runnable() {
            @Override
            public void run() {
			MzGameCenterPlatform.logout(MainActivity.this, new MzLoginListener() {
				@Override
				public void onLoginResult(int i, MzAccountInfo mzAccountInfo, String s) {

				}
			});
            }
        });
        UnityCallback.Invoke(UnityCallback.FuncName.Logout, "success");
	}

	@Override
	public void SDKServiceShowCenter(int pos) {
	}

	@Override
	public void SDKServicePurchase(final String productId,final String productName,final String amount,final String count,final String orderIdCom, final String exParam) {
//	    Bundle buyBundle = new MzBuyInfo().setBuyCount().setAppid().setCpUserInfo().setCreateTime().set

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
            try {
                JSONObject json = new JSONObject(exParam);
				Bundle buyBundle = new MzBuyInfo().setAppid(json.getString("app_id"))
						.setCreateTime(Long.valueOf(json.getString("create_time")))
						.setCpUserInfo(json.getString("user_info"))
						.setBuyCount(Integer.valueOf(json.getString("buy_amount")))
						.setOrderAmount(json.getString("total_price"))
						.setOrderId(json.getString("cp_order_id"))
						.setPayType(Integer.valueOf(json.getString("pay_type")))
						.setPerPrice(json.getString("product_per_price"))
						.setProductBody(json.getString("product_body"))
						.setProductId(json.getString("product_id"))
						.setProductSubject(json.getString("product_subject"))
						.setUserUid(json.getString("uid"))
						.setProductUnit(json.getString("product_unit"))
						.setSign(json.getString("sign"))
						.setSignType(json.getString("sign_type")).toBundle();

                MzGameCenterPlatform.payOnline(MainActivity.this, buyBundle, new MzPayListener() {
                    @Override
                    public void onPayResult(int i, Bundle bundle, String s) {
                    switch (i)
                    {
                        case PayResultCode.PAY_SUCCESS:
                            MzBuyInfo payinfo = MzBuyInfo.fromBundle(bundle);
                            //showInfo("支付成功：" + payinfo.getOrderId());
                            UnityCallback.OnPaySuccess(productId, orderIdCom, exParam, "", productId);
                            break;
                        default:
                            //showInfo("支付失败: " + s +", " + i );
                            UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(i), "");
                            break;
                    }
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
            }
        });
	}

	@Override
	public void SDKServiceExitSDK() {
	    runOnUiThread(new Runnable() {
            @Override
            public void run() {
            MzGameCenterPlatform.exitSDK(MainActivity.this, new MzExitListener() {
                @Override
                public void callback(int i, String s) {
                if(i == MzExitListener.CODE_SDK_EXIT)
                {
					UnityCallback.Invoke(UnityCallback.FuncName.Exit, "");
                }
                }
            });
            }
        });

	}

	@Override
	public void SDKServiceSubmitExtendData(String jsonStr) {

	}

	@Override
	public String getChannelName() {
		return null;
	}

	@Override
	public String getChannelVersion() {
		return null;
	}

	@Override
	public int getChannelType() {
		return 0;
	}

	@Override
	public String getSDKVersion() {
		return null;
	}

	@Override
	public boolean isChannelHasExitDialog() {
		return true;
	}

	private void showInfo(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }
}
