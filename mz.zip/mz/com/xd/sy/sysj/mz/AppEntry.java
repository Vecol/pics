package com.xd.sy.sysj.mz;

import android.app.Application;

import com.meizu.gamesdk.online.core.MzGameCenterPlatform;


/**
 * Created by Administrator on 2018/1/5.
 */

public class AppEntry extends Application {
    public static final String appid = "3190282";
    public static final String appkey = "5e6c5bdd80bb4a9f80b42264a6ef1444";
    public static final int channelID = 8;

    @Override
    public void onCreate() {
        super.onCreate();
        MzGameCenterPlatform.init(this, appid, appkey);

        UnityCallback.Invoke(UnityCallback.FuncName.Init, ","+channelID);
    }
}
