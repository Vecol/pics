package com.tencent.tmgp.xd.sy.sysj.wxapi;


/**
 * !!此文件的代码逻辑部分使用者不要修改
 */
public class WXEntryActivity extends com.tencent.ysdk.module.user.impl.wx.YSDKWXEntryActivity { }
