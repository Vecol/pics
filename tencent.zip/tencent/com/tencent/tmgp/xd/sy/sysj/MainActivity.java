package com.tencent.tmgp.xd.sy.sysj;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.hw.mag.Lanucher;
import com.tencent.connect.share.QQShare;
import com.tencent.tauth.Tencent;
import com.tencent.ysdk.api.YSDKApi;
import com.tencent.ysdk.framework.common.BaseRet;
import com.tencent.ysdk.framework.common.eFlag;
import com.tencent.ysdk.framework.common.ePlatform;
import com.tencent.ysdk.module.pay.PayListener;
import com.tencent.ysdk.module.pay.PayRet;
import com.tencent.ysdk.module.user.UserLoginRet;

import org.json.JSONObject;

public class MainActivity extends Lanucher implements ISDKBase
{
    protected static int platform = ePlatform.None.val();
    public static final int channelID = 13;
    public static final String APP_ID ="1106504875";
    public static final String LOG_TAG = "YSDK DEMO";
    public static final String LOCAL_ACTION = "com.tencent.tmgp.xd.sy.sysj";

    private ProgressDialog mAutoLoginWaitingDlg;
    public BroadcastReceiver mReceiver;
    public LocalBroadcastManager lbm;
    String zoneId;

	// Setup activity layout
	@Override protected void onCreate (Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		super.startup();

        YSDKApi.onCreate(this);
        YSDKApi.handleIntent(this.getIntent());

		YSDKApi.setUserListener(new YSDKCallback(this));
		YSDKApi.setBuglyListener(new YSDKCallback(this));
	}

	// Quit Unity
	@Override protected void onDestroy ()
	{
		super.onDestroy();

		YSDKApi.onDestroy(this);
	}

	// Pause Unity
	@Override protected void onPause()
	{
		super.onPause();

		YSDKApi.onPause(this);
	}

	// Resume Unity
	@Override protected void onResume()
	{
		super.onResume();
		YSDKApi.onResume(this);
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		YSDKApi.onRestart(this);
	}

    @Override
    protected void onStop() {
        super.onStop();
        YSDKApi.onStop(this);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        YSDKApi.handleIntent(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        YSDKApi.onActivityResult(requestCode, resultCode, data);
    }

    public void SDKServiceLogin_Platform(int platform)
    {
        YSDKApi.login(ePlatform.values()[platform]);
        startWaiting();
    }

	@Override
	public void SDKServiceInit() {
	    UnityCallback.Invoke(UnityCallback.FuncName.Init, ","+channelID);
	}

	@Override
	public void SDKServiceLogin() {
	    YSDKApi.login(ePlatform.WX);
    }

	@Override
	public void SDKServiceLogout() {
	    YSDKApi.logout();
        UnityCallback.Invoke(UnityCallback.FuncName.Logout, "");
	}

	@Override
	public void SDKServiceShowCenter(int pos) {

	}
    static String mProductId="";
	@Override
	public void SDKServicePurchase(final String productId,final String productName,final String amount,final String count,final String orderIdCom,final String exParam) {
        mProductId = productId;
        float f = Float.valueOf(amount)*10;
        int i = (int)f;

        try{
            JSONObject json = new JSONObject(exParam);
            zoneId = json.getString("zoneid");
        }catch (Exception e){
            e.printStackTrace();
        }

        //float f1=(float)(Math.round(f*100)/100);
        YSDKApi.recharge(zoneId, i+"",false,null,null,new PayListener() {
            @Override
            public void OnPayNotify(PayRet ret) {
                if(PayRet.RET_SUCC == ret.ret){
                    //支付流程成功
                    switch (ret.payState){
                        //支付成功
                        case PayRet.PAYSTATE_PAYSUCC:
                            sendResult("用户支付成功，支付金额"+ret.realSaveNum+";" +
                                            "使用渠道："+ret.payChannel+";" +
                                            "发货状态："+ret.provideState+";" +
                                            "业务类型："+ret.extendInfo+";建议查询余额："+ret.toString());
                            UnityCallback.OnPaySuccess(productId, orderIdCom, exParam, "", productId);
                            break;
                        //取消支付
                        case PayRet.PAYSTATE_PAYCANCEL:
                            sendResult("用户取消支付："+ret.toString());
                            UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(ret.payState), "");
                            break;
                        //支付结果未知
                        case PayRet.PAYSTATE_PAYUNKOWN:
                            sendResult("用户支付结果未知，建议查询余额："+ret.toString());
                            UnityCallback.OnPaySuccess(productId, orderIdCom, exParam, "", productId);
                            break;
                        //支付失败
                        case PayRet.PAYSTATE_PAYERROR:
                            sendResult("支付异常"+ret.toString());
                            UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(ret.payState), "");
                            break;
                    }
                }else{
                    switch (ret.flag){
                        case eFlag.Login_TokenInvalid:
                            //用户取消支付
                            sendResult("登陆态过期，请重新登陆："+ret.toString());
                            onLoginFail();
                            UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(ret.flag), "");
                            break;
                        case eFlag.Pay_User_Cancle:
                            //用户取消支付
                            sendResult("用户取消支付："+ret.toString());
                            UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(ret.flag), "");
                            break;
                        case eFlag.Pay_Param_Error:
                            sendResult("支付失败，参数错误"+ret.toString());
                            UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(ret.flag), "");
                            break;
                        case eFlag.Error:
                        default:
                            sendResult("支付异常"+ret.toString());
                            UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(ret.flag), "");
                            break;
                    }
                }
            }
        });

	}

	@Override
	public void SDKServiceExitSDK() {

	}

	@Override
	public void SDKServiceSubmitExtendData(String jsonStr) {
        // try{
        //     JSONObject json = new JSONObject(jsonStr);
        //     zoneId = json.getString("serverId");
        // }catch (Exception e){
        //     e.printStackTrace();
        // }
	}

	@Override
	public String getChannelName() {
		return null;
	}

	@Override
	public String getChannelVersion() {
		return null;
	}

	@Override
	public int getChannelType() {
		return 0;
	}

	@Override
	public String getSDKVersion() {
		return null;
	}

	@Override
	public boolean isChannelHasExitDialog() {
		return false;
	}

    public void showToastTips(String tips) {
        Toast.makeText(this,tips, Toast.LENGTH_LONG).show();
    }

    public void onLoginSuccess() {

        UserLoginRet ret = new UserLoginRet();
        int platform = YSDKApi.getLoginRecord(ret);
        String accessToken = ret.getAccessToken();
        String payToken = ret.getPayToken();
        String openid = ret.open_id;
        int flag = ret.flag;
        String msg = ret.msg;
        String pf = ret.pf;
        String pf_key = ret.pf_key;

        if(ret.ret != BaseRet.RET_SUCC)
        {
            onLoginFail();
            return;
        }

        try
        {
            JSONObject json = new JSONObject();
            json.put("userid", openid);
            json.put("platform", Integer.toString(platform));
            json.put("accesstoken", accessToken);
            json.put("paytoken", payToken);
            json.put("openid", openid);
            json.put("flag", Integer.toString(flag));
            json.put("msg", msg);
            json.put("pf", pf);
            json.put("pf_key", pf_key);

            UnityCallback.Invoke(UnityCallback.FuncName.Login, json.toString());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    public void onLoginFail() {
	    UnityCallback.Invoke(UnityCallback.FuncName.Login, "fail");
        YSDKApi.logout();
    }

    public void startWaiting() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d(LOG_TAG,"startWaiting");
                mAutoLoginWaitingDlg = new ProgressDialog(MainActivity.this);
                stopWaiting();
                mAutoLoginWaitingDlg.setTitle("登录中...");
                mAutoLoginWaitingDlg.show();
            }
        });

    }

    public void stopWaiting() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Log.d(LOG_TAG,"stopWaiting");
                if (mAutoLoginWaitingDlg != null && mAutoLoginWaitingDlg.isShowing()) {
                    mAutoLoginWaitingDlg.dismiss();
                }
            }
        });
    }


    public void showDiffLogin() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("异账号提示");
                builder.setMessage("你当前拉起的账号与你本地的账号不一致，请选择使用哪个账号登陆：");
                builder.setPositiveButton("本地账号",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int whichButton) {
                                showToastTips("选择使用本地账号");
                                onLoginFail();
                            }
                        });
                builder.setNeutralButton("拉起账号",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,
                                                int whichButton) {
                                showToastTips("选择使用拉起账号");
                                onLoginFail();
                            }
                        });
                builder.show();
            }
        });

    }

    public void sendResult(String result) {
//        if(lbm != null) {
//            Intent sendResult = new Intent(LOCAL_ACTION);
//            sendResult.putExtra("Result", result);
//            Log.d(LOG_TAG,"send: "+ result);
//            lbm.sendBroadcast(sendResult);
//        }
    }

}
