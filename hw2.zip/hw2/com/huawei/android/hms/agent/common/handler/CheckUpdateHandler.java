package com.huawei.android.hms.agent.common.handler;

/**
 * 应用自升级回调
 */
public interface CheckUpdateHandler extends ICallbackCode {
}
