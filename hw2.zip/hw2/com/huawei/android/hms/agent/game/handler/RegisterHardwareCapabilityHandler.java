package com.huawei.android.hms.agent.game.handler;

import com.huawei.android.hms.agent.common.handler.ICallbackCode;

/**
 * 保存玩家信息请求结果回调
 */
public interface RegisterHardwareCapabilityHandler extends ICallbackCode {
}
