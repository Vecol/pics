package com.xd.sy.sysj.hwtv.huawei;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.huawei.android.hms.agent.HMSAgent;
import com.huawei.android.hms.agent.common.handler.ConnectHandler;
import com.huawei.android.hms.agent.game.handler.LoginHandler;
import com.huawei.android.hms.agent.game.handler.SaveInfoHandler;
import com.huawei.android.hms.agent.pay.handler.PayHandler;
import com.huawei.hms.support.api.entity.game.GamePlayerInfo;
import com.huawei.hms.support.api.entity.game.GameUserData;
import com.huawei.hms.support.api.entity.pay.PayReq;
import com.huawei.hms.support.api.entity.pay.PayStatusCodes;
import com.huawei.hms.support.api.pay.PayResultInfo;
import com.hw.mag.Lanucher;

import org.json.JSONObject;

/**
 * Created by Administrator on 2018/1/15.
 */

public class MainActivity extends Lanucher implements ISDKBase{

    public final static String TAG = "sysj.hw";
    public final static int channelID = 2;

    @Override
    protected void onCreate(Bundle var1) {
        super.onCreate(var1);
        super.startup();

        HMSAgent.connect(this, new ConnectHandler() {
            @Override
            public void onConnect(int rst) {
                showLog("HMS connect end:" + rst);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        HMSAgent.Game.hideFloatWindow(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        HMSAgent.Game.showFloatWindow(this);
    }

    void showLog(String msg)
    {
        Log.i(TAG, "showLog: " + msg);
    }
    @Override
    public void SDKServiceInit() {
        UnityCallback.Invoke(UnityCallback.FuncName.Init, "," + channelID);
    }

    @Override
    public void SDKServiceLogin() {
        HMSAgent.Game.login(new LoginHandler() {
            @Override
            public void onResult(int retCode, GameUserData userData) {
                if (retCode == HMSAgent.AgentResultCode.HMSAGENT_SUCCESS && userData != null) {
                    showLog("game login: onResult: retCode=" + retCode +
                            "  user=" + userData.getDisplayName() + "|" + userData.getPlayerId() + "|" + userData.getIsAuth() + "|" + userData.getPlayerLevel());
                    // 当登录成功时，此方法会回调2次，
                    // 第1次：只回调了playerid；特点：速度快；在要求快速登录，并且对安全要求不高时可以用此playerid登录
                    // 第2次：回调了所有信息，userData.getIsAuth()为1；此时需要对登录结果进行验签
                    if (userData.getIsAuth() == 1) {
                        try{
                            JSONObject json = new JSONObject();
                            json.put("userid", userData.getPlayerId());
                            json.put("ts", userData.getTs());
                            json.put("playerid", userData.getPlayerId());
                            json.put("playerlevel", userData.getPlayerLevel().toString());
                            json.put("gameauthsign", userData.getGameAuthSign());

                            UnityCallback.Invoke(UnityCallback.FuncName.Login, json.toString());
                        }
                        catch (Exception e){
                            e.printStackTrace();
                        }

                    }
                } else {
                    showLog("game login: onResult: retCode=" + retCode);
                }
            }

            @Override
            public void onChange() {
                UnityCallback.Invoke(UnityCallback.FuncName.Logout, "");
                SDKServiceLogin();
            }
        }, 1);
    }

    @Override
    public void SDKServiceLogout() {
        SDKServiceLogin();
    }

    @Override
    public void SDKServiceShowCenter(int pos) {

    }
    static String mExParam="";
    @Override
    public void SDKServicePurchase(final String productId,final String productName,final String amount,final String count,final String orderIdCom,final String exParam) {
        mExParam = exParam;

        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject json = new JSONObject(mExParam);
                    PayReq payreq = new PayReq();
                    payreq.productName = json.getString("productName");
                    payreq.productDesc = json.getString("productDesc");
                    payreq.applicationID = json.getString("applicationID");
                    payreq.requestId = json.getString("requestId");
                    payreq.amount = json.getString("amount");
                    payreq.merchantId = json.getString("merchantId");
                    payreq.merchantName = json.getString("merchantName");
                    payreq.serviceCatalog = "X6";
                    payreq.sdkChannel = Integer.valueOf(json.getString("sdkChannel"));
                    payreq.url = json.getString("url");
                    payreq.currency = json.getString("currency");
                    payreq.country = json.getString("country");
                    payreq.urlVer = json.getString("urlVer");
                    // payreq.extReserved = json.getString("extreserved");
                    payreq.sign = json.getString("sign");
                    Log.i(TAG,"Purchase = "+payreq.productName+","+payreq.productDesc+","+ payreq.applicationID+","+payreq.requestId+","+payreq.url+","+payreq.merchantName);
                    HMSAgent.Pay.pay(payreq, new PayHandler() {
                        @Override
                        public void onResult(int retCode, PayResultInfo payInfo) {
                            if (retCode == PayStatusCodes.PAY_STATE_SUCCESS) {
                                //Toast.makeText(MainActivity.this, "充值成功", Toast.LENGTH_LONG).show();
                                //UnityCallback.Invoke(UnityCallback.FuncName.Pay, "success");
                                UnityCallback.OnPaySuccess(productId, orderIdCom, exParam, "", productId);
                            } else {
                                //Toast.makeText(MainActivity.this, "充值失败: " + retCode, Toast.LENGTH_LONG).show();
                                UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(retCode), "");
                            }

                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }


    @Override
    public void SDKServiceExitSDK() {

    }

    @Override
    public void SDKServiceSubmitExtendData(String jsonStr) {
        try {
            JSONObject jsonObject = new JSONObject(jsonStr);

            GamePlayerInfo gpi = new GamePlayerInfo();
            gpi.area = jsonObject.getString("serverName");
            gpi.rank = jsonObject.getString("roleLevel");
            gpi.role = jsonObject.getString("roleName");
            gpi.sociaty = "";
            HMSAgent.Game.savePlayerInfo(gpi, new SaveInfoHandler() {
                @Override
                public void onResult(int retCode) {
                    showLog("game savePlayerInfo: onResult=" + retCode);
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public String getChannelName() {
        return null;
    }

    @Override
    public String getChannelVersion() {
        return null;
    }

    @Override
    public int getChannelType() {
        return 0;
    }

    @Override
    public String getSDKVersion() {
        return null;
    }

    @Override
    public boolean isChannelHasExitDialog() {
        return false;
    }
}
