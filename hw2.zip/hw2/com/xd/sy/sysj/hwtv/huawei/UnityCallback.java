package com.xd.sy.sysj.hwtv.huawei;

import android.util.Log;

import com.unity3d.player.UnityPlayer;
import org.json.JSONObject;
/**
 * Created by Administrator on 2018/1/6.
 */

public class UnityCallback {

    static final String refObj = "SDKService";

    public enum FuncName
    {
        Init("OnInitCallback"),
        Login("OnLoginCallback"),
        ReLogin("OnChangeLoginCallback"),
        Logout("OnLogoutCallback"),
        Pay("OnPayCallback"),
        Log("OnLogCallback"),
        Exit("OnExitCallback");

        private final String text;
        FuncName(String t) {
            text = t;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    static public void Invoke(FuncName func, String param)
    {
        Log.i(refObj, "calling unity " + func.toString());
        UnityPlayer.UnitySendMessage(refObj, func.toString(), param);
    }

    static public void OnPaySuccess(String productID, String order, String exParam, String otherParam, String receipt)
    {
        try{
            JSONObject json = new JSONObject();
            json.put("result", "success");
            json.put("productid", productID);
            json.put("order", order);
            json.put("extParam", exParam);
            json.put("otherParam", otherParam);
            json.put("receipt", receipt);

            Invoke(FuncName.Pay, json.toString());
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    static public void OnPayFail(String productID, String order, String exParam, String otherParam, String errcode)
    {
        try{
            JSONObject json = new JSONObject();
            json.put("result", "fail");
            json.put("productid", productID);
            json.put("order", order);
            json.put("extParam", exParam);
            json.put("errcode", errcode);
            json.put("otherParam", otherParam);

            Invoke(FuncName.Pay, json.toString());
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
