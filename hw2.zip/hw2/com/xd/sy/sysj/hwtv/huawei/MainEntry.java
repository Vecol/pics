package com.xd.sy.sysj.hwtv.huawei;

import android.app.Application;

import com.huawei.android.hms.agent.HMSAgent;


/**
 * Created by Administrator on 2018/1/15.
 */

public class MainEntry extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        HMSAgent.init(this);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        HMSAgent.destroy();
    }
}
