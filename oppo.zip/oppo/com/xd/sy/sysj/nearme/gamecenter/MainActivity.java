package com.xd.sy.sysj.nearme.gamecenter;

import com.nearme.game.sdk.GameCenterSDK;
import com.nearme.game.sdk.callback.ApiCallback;
import com.nearme.game.sdk.callback.GameExitCallback;
import com.nearme.game.sdk.common.model.biz.PayInfo;
import com.nearme.game.sdk.common.model.biz.ReportUserGameInfoParam;
import com.nearme.game.sdk.common.model.biz.ReqUserInfoParam;
import com.unity3d.player.*;
import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONObject;
import com.hw.mag.Lanucher;
import java.util.Random;

public class MainActivity extends Lanucher implements ISDKBase
{
	public static final String TAG = "sysj.nearme";
	public static final String appID = "3610450";
    public static final int channelID = 6;

	@Override protected void onCreate (Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
        super.startup();
	}
	// Pause Unity
	@Override protected void onPause()
	{
		super.onPause();
		GameCenterSDK.getInstance().onPause();
	}

	// Resume Unity
	@Override protected void onResume()
	{
		super.onResume();
		GameCenterSDK.getInstance().onResume(this);
	}

	@Override
	public void SDKServiceInit() {
	    UnityCallback.Invoke(UnityCallback.FuncName.Init, ","+channelID);
	}

	@Override
	public void SDKServiceLogin() {
		GameCenterSDK.getInstance().doLogin(this.getApplicationContext(), new ApiCallback() {
			@Override
			public void onSuccess(String s) {
				getToken();
			}

			@Override
			public void onFailure(String s, int i) {
				Log.w(TAG, "onFailure: login");
				UnityCallback.Invoke(UnityCallback.FuncName.Login, "login fail");
			}
		});
	}

	void getToken()
	{
		GameCenterSDK.getInstance().doGetTokenAndSsoid(new ApiCallback() {
			@Override
			public void onSuccess(String s) {
				try
				{
					JSONObject json = new JSONObject(s);
					String token = json.getString("token");
					String ssoid = json.getString("ssoid");
					getUserInfo(token, ssoid);
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}

			@Override
			public void onFailure(String s, int i) {
				Log.w(TAG, "onFailure: GetTokenAndSsoid" + s);
				UnityCallback.Invoke(UnityCallback.FuncName.Login, "fail");
			}
		});
	}

	private void getUserInfo(final String token, final String ssoid) {
		GameCenterSDK.getInstance().doGetUserInfo(new ReqUserInfoParam(token, ssoid), new ApiCallback() {
			@Override
			public void onSuccess(String s) {
				try
				{
					JSONObject json = new JSONObject();
					json.put("userid", ssoid);
					json.put("sid", ssoid);
					json.put("session", token);
					UnityCallback.Invoke(UnityCallback.FuncName.Login, json.toString());
				}catch (Exception e){
					e.printStackTrace();
				}
			}

			@Override
			public void onFailure(String s, int i) {
				Log.w(TAG, "onFailure: getUserInfo" + s);
				UnityCallback.Invoke(UnityCallback.FuncName.Login, s);
			}
		});
	}

	@Override
	public void SDKServiceLogout() {
		UnityCallback.Invoke(UnityCallback.FuncName.Logout, "");
	}

	@Override
	public void SDKServiceShowCenter(int pos) {
		GameCenterSDK.getInstance().launchGameCenter(this.getApplicationContext());
	}

	@Override
	public void SDKServicePurchase(final String productId,final String productName,final String amount,final String count,final String orderIdCom,final String exParam) {
        try {
			Log.i(TAG, "購買" + productId);
			Float price = Float.valueOf(amount) * 100;
			PayInfo payInfo = new PayInfo( orderIdCom, "", price.intValue());
			payInfo.setProductName(productName);
			payInfo.setProductDesc(productName);
			payInfo.setCallbackUrl("http://111.230.145.36:7800/oppoCallback.php");

            GameCenterSDK.getInstance().doPay(this.getApplicationContext(), payInfo, new ApiCallback() {
                @Override
                public void onSuccess(String s) {
                    UnityCallback.Invoke(UnityCallback.FuncName.Pay, s);
                    //showInfo("支付成功");
                    UnityCallback.OnPaySuccess(productId, orderIdCom, exParam, "", productId);
                }

                @Override
                public void onFailure(String s, int i) {
                    UnityCallback.Invoke(UnityCallback.FuncName.Pay, s);
                    //showInfo("支付失败" + i + s);
                    UnityCallback.OnPayFail(productId, orderIdCom, exParam, String.valueOf(i), "");
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }

	}

	@Override
	public void SDKServiceExitSDK() {
		GameCenterSDK.getInstance().onExit(this, new GameExitCallback() {
			@Override
			public void exitGame() {
				UnityCallback.Invoke(UnityCallback.FuncName.Exit,"");
			}
		});
	}

	@Override
	public void SDKServiceSubmitExtendData(String jsonStr) {
		try {
			JSONObject jsonObject = new JSONObject(jsonStr);
			String zoneID = jsonObject.getString("serverId");
			String roleName = jsonObject.getString("roleName");
			String roleLevel = jsonObject.getString("roleLevel");
			GameCenterSDK.getInstance().doReportUserGameInfoData(
					new ReportUserGameInfoParam(appID, zoneID, roleName, roleLevel),
					new ApiCallback() {
						@Override
						public void onSuccess(String s) {
							Log.i(TAG, "onSuccess: submit player info");
						}

						@Override
						public void onFailure(String s, int i) {
							Log.i(TAG, "onFailure: submit player info");
						}
					});

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public String getChannelName() {
		return null;
	}

	@Override
	public String getChannelVersion() {
		return null;
	}

	@Override
	public int getChannelType() {
		return 0;
	}

	@Override
	public String getSDKVersion() {
		return null;
	}

	@Override
	public boolean isChannelHasExitDialog() {
		return true;
	}

    private void showInfo(String msg)
    {
        Toast.makeText(this.getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }

}
