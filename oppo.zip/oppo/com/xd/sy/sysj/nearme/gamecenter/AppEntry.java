package com.xd.sy.sysj.nearme.gamecenter;

import android.app.Application;

import com.nearme.game.sdk.GameCenterSDK;

/**
 * Created by Administrator on 2018/1/5.
 */

public class AppEntry extends Application {
    public static final String appSecret = "64Aad62f0CF37c1d53628267872ba845";
    public static final int channelID = 6;

    @Override
    public void onCreate() {
        super.onCreate();
        GameCenterSDK.init(appSecret, this);
        UnityCallback.Invoke(UnityCallback.FuncName.Init, ","+channelID);
    }
}
