package com.xd.sy.sysj.nearme.gamecenter;

/**
 * Created by Administrator on 2018/1/4.
 */

public interface ISDKBase {

    void SDKServiceInit();

    void SDKServiceLogin();

    void SDKServiceLogout();

    void SDKServiceShowCenter(int pos);

    void SDKServicePurchase(String productId, String productName, String amount, String count, String orderIdCom, String exParam);

    void SDKServiceExitSDK();

    void SDKServiceSubmitExtendData(String jsonStr);

    String getChannelName();

    String getChannelVersion();

    int getChannelType();

    String getSDKVersion();

    boolean isChannelHasExitDialog();

}
